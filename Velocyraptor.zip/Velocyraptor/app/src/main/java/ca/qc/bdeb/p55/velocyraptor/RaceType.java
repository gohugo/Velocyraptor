package ca.qc.bdeb.p55.velocyraptor;

/**
 * Un type de course.
 */
public enum RaceType {
    FOOT,
    BIKE
}
